import React from 'react';
import { View, StyleSheet, Image,Text } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Card from '../Shared/CartCard';


export default function Home(){
    return(
        <ScrollView>
            <View>
                <Text style={{fontSize: 60, fontWeight: 'bold', marginTop: 40, marginLeft: 10, color: '#CD051C'}}>Cart</Text>
            </View>
        <View style={{flexDirection: 'column'}}>
        <Card>
            <Image 
            style={{
                width: '100%',
                height: '65%',
                resizeMode: 'contain'
            }}
            source={require("../assets/Images/nike-metcon-3.png")}/>
            <View style={{marginLeft: 20}}>
            <Text style={{fontSize: 30, fontWeight: 'bold'}}>Nike Metcon</Text>
            </View>
            <View style={{flexDirection: 'row'}}>
                <Image 
            style={{
                width: 60,
                height: 30,
                marginLeft: 20
            }}
            source={require('../assets/Icons/rating.png')}/>
            <Image 
            style={{
                width: 30,
                height: 30,
                marginLeft: 80
            }}
            source={require('../assets/Icons/plus.png')}/>
            <Text style={{fontSize: 30, marginLeft:20}}>0</Text>
            <Image 
            style={{
                width: 20,
                height: 20,
                marginLeft: 30,
                marginTop: 5
            }}
            source={require('../assets/Icons/minus-sign.png')}/>
            
            </View>
            <View style={{marginLeft: 280, marginTop: 30}}>
            <Text style={{fontSize: 20, fontWeight: '400'}}>$200</Text>
            </View>
        </Card>


        <Card>
            <Image 
            style={{
                width: '100%',
                height: '65%',
                resizeMode: 'contain'
            }}
            source={require("../assets/Images/nike-metcon-4.png")}/>
            <View style={{marginLeft: 20}}>
            <Text style={{fontSize: 30, fontWeight: 'bold'}}>Nike Metcon4</Text>
            </View>
            <View style={{flexDirection: 'row'}}>
                <Image 
            style={{
                width: 60,
                height: 30,
                marginLeft: 20
            }}
            source={require('../assets/Icons/rating.png')}/>
            <Image 
            style={{
                width: 30,
                height: 30,
                marginLeft: 80
            }}
            source={require('../assets/Icons/plus.png')}/>
            <Text style={{fontSize: 30, marginLeft:20}}>0</Text>
            <Image 
            style={{
                width: 20,
                height: 20,
                marginLeft: 30,
                marginTop: 5
            }}
            source={require('../assets/Icons/minus-sign.png')}/>
            
            </View>
            <View style={{marginLeft: 280, marginTop: 30}}>
            <Text style={{fontSize: 20, fontWeight: '400'}}>$200</Text>
            </View>
        </Card>


        <Card>
            <Image 
            style={{
                width: '100%',
                height: '65%',
                resizeMode: 'contain'
            }}
            source={require("../assets/Images/nike-metcon-5-black.png")}/>
            <View style={{marginLeft: 20}}>
            <Text style={{fontSize: 30, fontWeight: 'bold'}}>Nike Metcon5</Text>
            </View>
            <View style={{flexDirection: 'row'}}>
                <Image 
            style={{
                width: 60,
                height: 30,
                marginLeft: 20
            }}
            source={require('../assets/Icons/rating.png')}/>
            <Image 
            style={{
                width: 30,
                height: 30,
                marginLeft: 80
            }}
            source={require('../assets/Icons/plus.png')}/>
            <Text style={{fontSize: 30, marginLeft:20}}>0</Text>
            <Image 
            style={{
                width: 20,
                height: 20,
                marginLeft: 30,
                marginTop: 5
            }}
            source={require('../assets/Icons/minus-sign.png')}/>
            
            </View>
            <View style={{marginLeft: 280, marginTop: 30}}>
            <Text style={{fontSize: 20, fontWeight: '400'}}>$200</Text>
            </View>
        </Card>

        <Card>
            <Image 
            style={{
                width: '100%',
                height: '65%',
                resizeMode: 'contain'
            }}
            source={require("../assets/Images/nike-metcon-5-purple.png")}/>
            <View style={{marginLeft: 20}}>
            <Text style={{fontSize: 30, fontWeight: 'bold'}}>Nike Metcon5</Text>
            </View>
            <View style={{flexDirection: 'row'}}>
                <Image 
            style={{
                width: 60,
                height: 30,
                marginLeft: 20
            }}
            source={require('../assets/Icons/rating.png')}/>
            <Image 
            style={{
                width: 30,
                height: 30,
                marginLeft: 80
            }}
            source={require('../assets/Icons/plus.png')}/>
            <Text style={{fontSize: 30, marginLeft:20}}>0</Text>
            <Image 
            style={{
                width: 20,
                height: 20,
                marginLeft: 30,
                marginTop: 5
            }}
            source={require('../assets/Icons/minus-sign.png')}/>
            
            </View>
            <View style={{marginLeft: 280, marginTop: 30}}>
            <Text style={{fontSize: 20, fontWeight: '400'}}>$200</Text>
            </View>
        </Card>


        <Card>
            <Image 
            style={{
                width: '100%',
                height: '65%',
                resizeMode: 'contain'
            }}
            source={require("../assets/Images/nike-zoom-kobe-1-protro.png")}/>
            <View style={{marginLeft: 20}}>
            <Text style={{fontSize: 30, fontWeight: 'bold'}}>Nike zoom</Text>
            </View>
            <View style={{flexDirection: 'row'}}>
                <Image 
            style={{
                width: 60,
                height: 30,
                marginLeft: 20
            }}
            source={require('../assets/Icons/rating.png')}/>
            <Image 
            style={{
                width: 30,
                height: 30,
                marginLeft: 80
            }}
            source={require('../assets/Icons/plus.png')}/>
            <Text style={{fontSize: 30, marginLeft:20}}>0</Text>
            <Image 
            style={{
                width: 20,
                height: 20,
                marginLeft: 30,
                marginTop: 5
            }}
            source={require('../assets/Icons/minus-sign.png')}/>
            
            </View>
            <View style={{marginLeft: 280, marginTop: 30}}>
            <Text style={{fontSize: 20, fontWeight: '400'}}>$200</Text>
            </View>
        </Card>
    </View>
    </ScrollView>
    )
}

const styles = StyleSheet.create({
    Image: {
        width: 300,
        height: 300,
    },
})