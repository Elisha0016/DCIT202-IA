import 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack'; 
import Login from './screens/Login';
import Home from './screens/Home';
import Cart from './screens/Cart';
import Details from './screens/Details';
import met4 from './screens/met4';
import met5 from './screens/met5';
import met5p from './screens/met5p';
import zoom from './screens/zoom';



export default function App() {
  const MainNavgator = createStackNavigator();

  return (
    <View style={{flex: 1}}>
     <NavigationContainer>
       <MainNavgator.Navigator screenOptions={{headerShown: false}} initialRouteName="Login">
         <MainNavgator.Screen name="Login" component={Login} />
         <MainNavgator.Screen name="Home" component={Home} />
         <MainNavgator.Screen name="Cart" component={Cart} />
         <MainNavgator.Screen name="Details" component={Details} />
         <MainNavgator.Screen name="met4" component={met4} />
         <MainNavgator.Screen name="met5" component={met5} />
         <MainNavgator.Screen name="met5p" component={met5p} />
         <MainNavgator.Screen name="zoom" component={zoom} />
       </MainNavgator.Navigator>
     </NavigationContainer>
     
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
