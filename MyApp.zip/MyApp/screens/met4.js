import React from "react";
import {StyleSheet, View, Image, Text} from "react-native";
import { ScrollView, TouchableOpacity } from "react-native-gesture-handler";
import Card from "../Shared/Card";

export default function met4({navigation}) {
    return(
        <View style={{backgroundColor: 'white', flex: 1, paddingTop: 55, paddingHorizontal: 20}}>
            <View style={{flexDirection: 'row', justifyContent: 'space-evenly', marginBottom: 20 }}>
                <TouchableOpacity>
                <Image 
                style={{
                    width: 30,
                    height: 30,
                    tintColor: '#cd051c'
                }}
                source={require("../assets/Icons/menu.png")}/>
                </TouchableOpacity>
                
                <Image style={{
                    width: 30,
                    height: 30,
                    marginLeft: 120,
                    marginRight: 120,
                    tintColor: '#cd051c'
                }}
                source={require("../assets/Icons/sneakers.png")}/>

                <TouchableOpacity 
                onPress={() => {
                    navigation.navigate("Cart")}}>

        <View style={{
                    position: 'absolute', height: 30, width: 30, borderRadius: 15, backgroundColor: '#cd051c', right: 15,
                    bottom: 15, alignItems: 'center', justifyContent: 'center', zIndex: 2000
                }}>
                    <Text style={{color: 'white', fontWeight: 'bold'}}>0</Text>
                    </View>
                <Image 
                style={{
                    width: 30,
                    height: 30,
                    tintColor: '#cd051c'
                }}
                source={require("../assets/Icons/shopping-cart.png")}/>
                </TouchableOpacity>
               
            </View>
                
    
        <View>
            <ScrollView>
                <View style={{flexDirection: 'column',marginTop: 20, marginRight: 5}}>
                <Card>
                    <Image 
                        style={{
                            width: '100%',
                            height: '65%',
                            resizeMode: 'contain'
                        }}
                        source={require("../assets/Images/nike-metcon-4.png")}/>
                        <View style={{marginLeft: 20}}>
                        <Text style={{fontSize: 30, fontWeight: 'bold'}}>Nike Metcon4</Text>
                        </View>
                        <View>
                            <Image 
                        style={{
                            width: 60,
                            height: 30,
                            marginLeft: 20
                        }}
                        source={require('../assets/Icons/rating.png')}/>
                        </View>
                        <View style={{marginLeft: 225}}>
                        <Text style={{fontSize: 20, fontWeight: '400'}}>$200</Text>
                        </View>
                </Card>
                </View>

                <View>
                <TouchableOpacity 
            onPress={() => {
                navigation.navigate("Cart")
            }}
            style={{backgroundColor: '#cd051c',
                    padding: 10, 
                    paddingHorizontal: 60, 
                    marginTop: 20,
                    borderRadius: 10,
                    flexDirection: 'row',
                    }}>
                <Text style={{fontSize: 20, color: 'white', marginLeft: 60}}>Add To Cart</Text>
            </TouchableOpacity>
                </View>
            </ScrollView>
        </View>
    </View>
    )

}