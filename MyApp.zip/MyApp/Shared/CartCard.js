import React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import { ScrollView, TouchableOpacity } from 'react-native-gesture-handler';


export default function Card(props) {
    return(
        <View style={styles.card}>
            
            <View style={styles.cardContent}>
                {props.children}
            </View>
        </View>
    )
}



const styles = StyleSheet.create({
    card: {
        borderRadius: 12,
        elevation: 3,
        backgroundColor: 'white',
        shadowOffset: {width: 1, height: 1},
        shadowColor: '#333',
        shadowOpacity: 0.3,
        shadowRadius: 2,
        marginHorizontal: 4,
        marginVertical: 20,
        width: '95%',
        height: 400,
        marginLeft: 11
    },
    cardContent: {
        marginVertical: 10,
    }
})

